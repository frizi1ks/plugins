package frizi1ks.tutorial;

import frizi1ks.tutorial.Listeners.*;
import frizi1ks.tutorial.commands.ColorMsgCommand;
import frizi1ks.tutorial.commands.GetitemsCommand;
import frizi1ks.tutorial.commands.RollComand;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class Tutorial extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic

        getCommand("roll").setExecutor(new RollComand());
        getCommand("color-msg").setExecutor(new ColorMsgCommand());
        getCommand("get-items").setExecutor(new GetitemsCommand());

        PluginManager pluginManger = Bukkit.getPluginManager();

        pluginManger.registerEvents(new JoinQuitPlayer(), this);

        pluginManger.registerEvents(new BlackBreak(), this);

        pluginManger.registerEvents(new PlayerClick(), this);

        pluginManger.registerEvents(new PlayerClick1(), this);

        pluginManger.registerEvents(new PlayerClick2(), this);

        pluginManger.registerEvents(new PlayerClick3(), this);

        pluginManger.registerEvents(new PlayerClick4(), this);

        pluginManger.registerEvents(new PlayerClick5(), this);

        pluginManger.registerEvents(new PlayerClick6(), this);

        pluginManger.registerEvents(new ScoreBoardJoin(), this);
    }
}
