package frizi1ks.tutorial.Listeners;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

public class PlayerClick1 implements Listener {

    @EventHandler
    private void PlayerInteract(PlayerInteractEvent e) {

        if (e.getAction().isLeftClick()) return;
        if (e.getItem() == null) return;
        if (!e.getItem().getType().equals(Material.WOODEN_AXE)) return;

        Block block = e.getClickedBlock();

        if (block == null) return;
        if (!block.getType().equals(Material.STONE)) return;

        block.setType(Material.DIAMOND_BLOCK);

    }
}
