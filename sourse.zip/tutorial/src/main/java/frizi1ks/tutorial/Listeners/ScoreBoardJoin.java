package frizi1ks.tutorial.Listeners;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scoreboard.*;

public class ScoreBoardJoin implements Listener {

    @EventHandler
    private void onJoin(PlayerJoinEvent e) {

        Player player = e.getPlayer();

        ScoreboardManager scoreboardManager = Bukkit.getScoreboardManager();

        Scoreboard scoreboard = scoreboardManager.getNewScoreboard();

        Objective objective = scoreboard.registerNewObjective(player.getName() + "score", Criteria.DUMMY, Component.text("§4====== TG: @pluginfrizi1k ======"));

        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        objective.getScore("§4=                       ").setScore(11);
        objective.getScore("§4=  §bМонетки: ").setScore(7);
        objective.getScore("§4=  §bТокены: ").setScore(8);
        objective.getScore("§4=  §bВаш ник: " + player.getName()).setScore(10);
        objective.getScore("§4=  §bДонат: ").setScore(9);
        objective.getScore("§4======= TG: @pluginfrizi1k ============").setScore(6);
        objective.getScore("§4=                      ").setScore(5);
        objective.getScore("§4=  §bНаигранное время: ").setScore(4);
        objective.getScore("§4=  §bУбийств: ").setScore(3);
        objective.getScore("§4=  §bСмертей: ").setScore(2);
        objective.getScore("§4=  §bTG: @pluginfrizi1k").setScore(1);
        objective.getScore("§4===================").setScore(0);


        player.setScoreboard(scoreboard);
    }
}