package frizi1ks.tutorial.Listeners;

import org.bukkit.Material;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class JoinQuitPlayer implements Listener {

    @EventHandler
    private void JoinServer(PlayerJoinEvent e) {

        Player player = e.getPlayer();

        e.setJoinMessage("§6Игрок §b" + player.getName() + " §6присоединился на сервер!");

        ItemStack item = new ItemStack(Material.APPLE, 2);

        player.getInventory().addItem(item);


    }

    @EventHandler
    private void QuitServer(PlayerQuitEvent e) {

        Player player = e.getPlayer();

        e.setQuitMessage("§6Игрок §b" + player.getName() + " §6покинул наш сервер!");


    }
}
