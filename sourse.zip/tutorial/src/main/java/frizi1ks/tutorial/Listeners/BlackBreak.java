package frizi1ks.tutorial.Listeners;

import io.papermc.paper.event.block.BlockBreakBlockEvent;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class BlackBreak implements Listener {

    @EventHandler
    public void playerBlockBreak(BlockBreakEvent e) {

        Player player = e.getPlayer();

        if  (player.getInventory().getItemInMainHand().getType().equals(Material.STICK)) {
            player.sendMessage("§6Палкой нельзя ломать блоки!");
            e.setCancelled(true);
        }
    }
}
