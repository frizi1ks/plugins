package frizi1ks.tutorial.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ColorMsgCommand implements CommandExecutor, TabCompleter {
    @Override
    public boolean onCommand(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String @NotNull [] strings) {

        if (!(commandSender instanceof Player)) return false;
        Player player = (Player) commandSender;

        if (strings.length < 2) {
            player.sendMessage("§6Вы не ввели ник игрока и цвет своего сообщения.");

            return false;
        }

        Player target = Bukkit.getPlayer(strings[0]);

        if (target == null) {
            player.sendMessage("§6Данный игрок не в сети!");
            return false;
        }

        String color = "";

        if (strings[1].equals("red")) {
            color = "§4";
        }else if (strings[1].equals("green")) {
            color = "§2";
        }else if (strings[1].equals("blue")) {
            color = "§1";
        }

        for (int i = 2; i < strings.length; i++) {
            color += strings[i] + " ";
        }
player.sendMessage("§6Сообщение отправлено игроку §b" + target.getName());
        target.sendMessage("§r" + player.getName() + " > " + color );

        return false;

    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String @NotNull [] strings) {
        List<String> tab = new ArrayList<>();
        if (strings.length == 1) {

            for(Player player : Bukkit.getOnlinePlayers()) {
                tab.add(player.getName());
            }
        }

        if (strings.length == 2) {
            tab.add("red");
            tab.add("green");
            tab.add("blue");
        }

        return tab;
    }
}
